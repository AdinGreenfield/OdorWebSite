# Be sure to restart your server when you modify this file.

OdorWebsite::Application.config.session_store :cookie_store, key: '_odor_website_session'
